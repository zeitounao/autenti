

para rodar o "scripts": "test": "frase aleatoria" aplica no terminal o codigo npm run test
ou podemos rodar o "scripts": "start" usando o codigo "npm start" e no caso vai rodar o index.js

"npm i opn -g" instala o modulo "opn" de forma global "-g" e pode ser usado em todos os projetos 
para ver aonde o opg esta instalado uso o comando "npm root -g"
para desinstalar usa o comando "npm uninstall opn -g" 