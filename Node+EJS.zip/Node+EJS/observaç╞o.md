<%- serve para falar para a classe que o comando a seguir vai funcionar apenas no ejs
%> serve para definir o fim do comando
O include('head') serve para anexar o arquivo head, assim se tivermos varias paginas o cabeçalho vai ser igual, da para fazer o mesmo com o footer head e header igual o CSS

alterações em ejs nao precisam parar o servidor/terminal para funcionar mas 
se for feito alterações no js precisa parar usando o ctrl+c e depois o node server.js 

